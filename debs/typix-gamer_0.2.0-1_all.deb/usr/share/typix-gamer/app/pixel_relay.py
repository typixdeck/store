#!/usr/bin/env python3
"""Pixel Relay native Raspberry Pi launcher (GTK + RetroArch, no WebView)."""

from __future__ import annotations

import json
import hashlib
import math
import os
import re
import shutil
import sqlite3
import stat
import subprocess
import sys
import threading
import zipfile
from concurrent.futures import Future, ThreadPoolExecutor
from pathlib import Path, PurePosixPath

try:
    import gi

    gi.require_version("Gdk", "3.0")
    gi.require_version("Gtk", "3.0")
    from gi.repository import Gdk, GdkPixbuf, Gio, GLib, Gtk
except (ImportError, ValueError) as exc:
    print("缺少 GTK 运行库，请执行 pi-app/install.sh 安装。", file=sys.stderr)
    raise SystemExit(2) from exc


APP_DIR = Path(__file__).resolve().parent
PROJECT_DIR = APP_DIR.parent
DATA_DIR = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share")) / "pixel-relay"
USER_ROM_DIR = DATA_DIR / "roms"
USER_LIBRARY = DATA_DIR / "library.json"
NETWORK_ROM_ROOT = Path(
    os.environ.get("PIXEL_RELAY_NETWORK_ROM_ROOT", DATA_DIR / "network-roms")
)
NETWORK_MOUNT_ROOT = Path(
    os.environ.get("PIXEL_RELAY_NETWORK_MOUNT_ROOT", "/mnt/typix-rom")
)
CACHE_DIR = Path(os.environ.get("XDG_CACHE_HOME", Path.home() / ".cache")) / "pixel-relay"
INDEX_DB = CACHE_DIR / "library.sqlite3"
THUMBNAIL_DIR = CACHE_DIR / "thumbnails"
WINDOWED = "--windowed" in sys.argv
POSTER_PAGE_SIZE = 16
INDEX_SCHEMA_VERSION = "1"
COVER_EXTENSIONS = (".jpg", ".jpeg", ".png", ".webp")

SYSTEMS = {
    "nes": {
        "name": "红白机 / NES",
        "extensions": {".nes", ".zip"},
        "cores": ["nestopia_libretro.so", "fceumm_libretro.so"],
    },
    "gb": {
        "name": "Game Boy",
        "extensions": {".gb", ".gbc", ".zip"},
        "cores": ["gambatte_libretro.so", "mgba_libretro.so"],
    },
    "gba": {
        "name": "Game Boy Advance",
        "extensions": {".gba", ".zip"},
        "cores": ["mgba_libretro.so", "vbam_libretro.so"],
    },
    "genesis": {
        "name": "Mega Drive / Genesis",
        "extensions": {".md", ".gen", ".bin", ".zip"},
        "cores": ["genesis_plus_gx_libretro.so", "picodrive_libretro.so"],
    },
    "snes": {
        "name": "超级任天堂 / SNES",
        "extensions": {".sfc", ".smc", ".zip"},
        "cores": ["snes9x_libretro.so", "snes9x2010_libretro.so"],
    },
    "atari2600": {
        "name": "Atari 2600",
        "extensions": {".a26", ".zip"},
        "cores": ["stella_libretro.so", "stella2014_libretro.so"],
    },
    "n64": {
        "name": "Nintendo 64",
        "extensions": {".n64", ".v64", ".z64", ".zip"},
        "cores": ["mupen64plus_next_libretro.so", "parallel_n64_libretro.so"],
    },
    "dos": {
        "name": "DOS / PC",
        "extensions": {".zip"},
        "cores": ["dosbox_pure_libretro.so"],
    },
}

FILTER_LABELS = {
    "all": "全部",
    "nes": "NES",
    "gb": "GB",
    "gba": "GBA",
    "genesis": "MD",
    "snes": "SNES",
    "atari2600": "2600",
    "n64": "N64",
    "dos": "DOS",
}

CORE_DIRS = [
    Path("/usr/lib/aarch64-linux-gnu/libretro"),
    Path("/usr/lib/arm-linux-gnueabihf/libretro"),
    Path("/usr/lib/x86_64-linux-gnu/libretro"),
    Path("/usr/lib/libretro"),
    Path.home() / ".config/retroarch/cores",
]


def resolve_asset(path_value: str) -> Path:
    candidate = Path(path_value)
    if candidate.is_absolute():
        return candidate
    for root in (PROJECT_DIR, APP_DIR):
        path = (root / candidate).resolve()
        if path.exists():
            return path
    return (PROJECT_DIR / candidate).resolve()


def find_core(system: str) -> Path | None:
    for core_name in SYSTEMS[system]["cores"]:
        for core_dir in CORE_DIRS:
            candidate = core_dir / core_name
            if candidate.exists():
                return candidate
    return None


def load_local_games() -> tuple[list[dict], list[dict]]:
    bundled = json.loads((APP_DIR / "library.json").read_text(encoding="utf-8"))["games"]
    user_games: list[dict] = []
    if USER_LIBRARY.exists():
        try:
            user_games = json.loads(USER_LIBRARY.read_text(encoding="utf-8")).get("games", [])
        except (OSError, json.JSONDecodeError):
            user_games = []
    # The old deployment tree optionally carried public-domain ROMs under public/.
    # Package builds are smaller without them; only show bundled entries whose
    # declared ROM is actually present.
    bundled = [game for game in bundled if resolve_asset(game.get("rom", "")).is_file()]
    return user_games, bundled


def load_network_games() -> list[dict]:
    games: list[dict] = []
    for system, config in SYSTEMS.items():
        system_dir = NETWORK_ROM_ROOT / system
        if not system_dir.is_dir():
            continue
        try:
            paths: list[Path] = []
            visited: set[tuple[int, int]] = set()
            for root, directories, filenames in os.walk(system_dir, followlinks=True):
                root_path = Path(root)
                stat = root_path.stat()
                identity = (stat.st_dev, stat.st_ino)
                if identity in visited:
                    directories.clear()
                    continue
                visited.add(identity)
                directories[:] = [
                    name
                    for name in directories
                    if not name.startswith(".")
                    and name.casefold() not in {"media", "#recycle"}
                ]
                for filename in filenames:
                    if filename.startswith("."):
                        continue
                    path = root_path / filename
                    if path.suffix.lower() in config["extensions"]:
                        paths.append(path)
            paths.sort(key=lambda path: path.name.casefold())
        except OSError:
            continue
        for path in paths:
            relative = path.relative_to(system_dir)
            title = path.stem.replace("_", " ").replace("-", " ").strip()
            games.append(
                {
                    "id": f"network-{system}-{relative.as_posix()}",
                    "title": title or path.name,
                    "system": system,
                    "rom": str(path),
                    "description": f"局域网 ROM · {relative.parent}",
                    "network": True,
                }
            )
    return games


def find_cover(game: dict) -> Path | None:
    configured = game.get("cover")
    if configured:
        candidate = resolve_asset(configured)
        if candidate.is_file():
            return candidate
    rom = resolve_asset(game["rom"])
    for extension in COVER_EXTENSIONS:
        candidate = rom.with_suffix(extension)
        if candidate.is_file():
            return candidate
    media_dir = rom.parent / "media" / rom.stem
    for stem in ("boxFront", "boxfront", "cover", "poster"):
        for extension in COVER_EXTENSIONS:
            candidate = media_dir / f"{stem}{extension}"
            if candidate.is_file():
                return candidate
    return None


def _existing_network_games() -> list[dict]:
    if not INDEX_DB.exists():
        return []
    try:
        with sqlite3.connect(INDEX_DB) as connection:
            connection.row_factory = sqlite3.Row
            rows = connection.execute(
                """SELECT id, title, system, rom, description, cover, license, network
                   FROM games WHERE network = 1 ORDER BY source_rank"""
            ).fetchall()
    except sqlite3.Error:
        return []
    return [dict(row) for row in rows]


def rebuild_game_index() -> int:
    """Scan sources only on demand and atomically replace the local index."""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    network_games = load_network_games()
    if not network_games:
        # Keep the last good NAS catalogue while the server is asleep/offline.
        network_games = _existing_network_games()
    user_games, bundled = load_local_games()
    games = network_games + user_games + bundled
    temporary = INDEX_DB.with_suffix(f".sqlite3.{os.getpid()}.tmp")
    try:
        temporary.unlink(missing_ok=True)
        with sqlite3.connect(temporary) as connection:
            connection.executescript(
                """
                PRAGMA journal_mode=OFF;
                PRAGMA synchronous=OFF;
                CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                CREATE TABLE games (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    system TEXT NOT NULL,
                    rom TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    cover TEXT NOT NULL DEFAULT '',
                    license TEXT NOT NULL DEFAULT '',
                    network INTEGER NOT NULL DEFAULT 0,
                    source_rank INTEGER NOT NULL
                );
                CREATE INDEX games_system_rank ON games(system, source_rank);
                CREATE INDEX games_network ON games(network);
                """
            )
            connection.execute(
                "INSERT INTO metadata(key, value) VALUES('schema_version', ?)",
                (INDEX_SCHEMA_VERSION,),
            )
            connection.executemany(
                """INSERT OR REPLACE INTO games
                   (id, title, system, rom, description, cover, license, network, source_rank)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                [
                    (
                        str(game["id"]),
                        str(game["title"]),
                        str(game["system"]),
                        str(game["rom"]),
                        str(game.get("description", "")),
                        str(game.get("cover", "")),
                        str(game.get("license", "")),
                        1 if game.get("network") else 0,
                        rank,
                    )
                    for rank, game in enumerate(games)
                ],
            )
        os.replace(temporary, INDEX_DB)
    finally:
        temporary.unlink(missing_ok=True)
    return len(games)


def ensure_game_index() -> None:
    try:
        with sqlite3.connect(INDEX_DB) as connection:
            version = connection.execute(
                "SELECT value FROM metadata WHERE key = 'schema_version'"
            ).fetchone()
        if version and version[0] == INDEX_SCHEMA_VERSION:
            return
    except (OSError, sqlite3.Error):
        pass
    rebuild_game_index()


def query_game_page(system: str, page: int) -> tuple[list[dict], int]:
    where = "" if system == "all" else " WHERE system = ?"
    parameters: tuple[object, ...] = () if system == "all" else (system,)
    with sqlite3.connect(INDEX_DB) as connection:
        connection.row_factory = sqlite3.Row
        total = connection.execute(f"SELECT COUNT(*) FROM games{where}", parameters).fetchone()[0]
        rows = connection.execute(
            f"""SELECT id, title, system, rom, description, cover, license, network
                FROM games{where} ORDER BY source_rank LIMIT ? OFFSET ?""",
            (*parameters, POSTER_PAGE_SIZE, page * POSTER_PAGE_SIZE),
        ).fetchall()
    return [dict(row) for row in rows], int(total)


def indexed_network_count() -> int:
    try:
        with sqlite3.connect(INDEX_DB) as connection:
            return int(connection.execute("SELECT COUNT(*) FROM games WHERE network = 1").fetchone()[0])
    except sqlite3.Error:
        return 0


def thumbnail_path(game: dict) -> Path:
    digest = hashlib.sha256(str(game["id"]).encode("utf-8")).hexdigest()
    return THUMBNAIL_DIR / f"{digest}.jpg"


def build_thumbnail(game: dict) -> Path | None:
    destination = thumbnail_path(game)
    if destination.is_file():
        return destination
    cover = find_cover(game)
    if cover is None:
        return None
    THUMBNAIL_DIR.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(f".{threading.get_ident()}.tmp")
    try:
        pixbuf = GdkPixbuf.Pixbuf.new_from_file_at_scale(str(cover), 260, 202, True)
        pixbuf.savev(str(temporary), "jpeg", ["quality"], ["84"])
        os.replace(temporary, destination)
        return destination
    except (GLib.Error, OSError):
        return None
    finally:
        temporary.unlink(missing_ok=True)


def network_mount_state() -> str:
    """Return a cheap, refresh-time-only status for the configured ROM share."""
    if os.path.ismount(NETWORK_MOUNT_ROOT):
        return "mounted"
    try:
        if any(path.is_symlink() for path in NETWORK_ROM_ROOT.iterdir()):
            return "configured"
    except OSError:
        pass
    return "unconfigured"


def decode_legacy_zip_name(member: zipfile.ZipInfo) -> str:
    """Recover old mainland-Chinese ZIP names stored without the UTF-8 flag."""
    name = member.filename
    if member.flag_bits & 0x800:
        return name
    try:
        raw = name.encode("cp437")
    except UnicodeEncodeError:
        return name
    candidates = [name]
    for encoding in ("gb18030", "big5"):
        try:
            candidates.append(raw.decode(encoding))
        except UnicodeDecodeError:
            continue

    def score(value: str) -> int:
        cjk = sum("\u3400" <= char <= "\u9fff" for char in value)
        box_drawing = sum("\u2500" <= char <= "\u259f" for char in value)
        controls = sum(ord(char) < 32 and char not in "\t\r\n" for char in value)
        return cjk * 4 - box_drawing * 5 - controls * 10

    return max(candidates, key=score)


def safe_extract(zip_path: Path, destination: Path) -> None:
    destination_resolved = destination.resolve()
    with zipfile.ZipFile(zip_path) as archive:
        for member in archive.infolist():
            member_name = decode_legacy_zip_name(member).replace("\\", "/")
            relative = PurePosixPath(member_name)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError("压缩包包含不安全路径")
            target = destination.joinpath(*relative.parts).resolve()
            if destination_resolved not in target.parents and target != destination_resolved:
                raise ValueError("压缩包包含不安全路径")
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode):
                continue
            if member.is_dir() or member_name.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(member) as source, target.open("wb") as output:
                shutil.copyfileobj(source, output)


def decode_dos_readme(path: Path) -> str:
    try:
        data = path.read_bytes()
    except OSError:
        return ""
    if len(data) > 512 * 1024:
        return ""
    for encoding in ("utf-8-sig", "gb18030", "big5"):
        try:
            return data.decode(encoding)
        except UnicodeDecodeError:
            continue
    return data.decode("latin-1", errors="replace")


def find_dos_startup(destination: Path) -> Path | None:
    candidates = sorted(
        (
            path
            for path in destination.rglob("*")
            if path.is_file() and path.suffix.casefold() in {".bat", ".com", ".exe"}
        ),
        key=lambda path: (len(path.relative_to(destination).parts), path.name.casefold()),
    )
    if not candidates:
        return None
    by_name: dict[str, list[Path]] = {}
    for path in candidates:
        by_name.setdefault(path.name.casefold(), []).append(path)

    # Old game packs commonly document the exact launch command in a GBK readme.
    readmes = [
        path
        for path in destination.rglob("*")
        if path.is_file()
        and (path.name.casefold().startswith("readme") or path.suffix.casefold() in {".txt", ".nfo"})
    ]
    command_pattern = re.compile(r"(?i)([a-z0-9][a-z0-9_.-]{0,39}\.(?:bat|com|exe))")
    for readme in readmes:
        for command_name in command_pattern.findall(decode_dos_readme(readme)):
            matches = by_name.get(command_name.casefold())
            if matches:
                return matches[0]

    for stem in ("dosbox", "play", "start", "run", "launch", "game", "san4", "sword", "stardom", "main"):
        for extension in (".bat", ".com", ".exe"):
            matches = by_name.get(f"{stem}{extension}")
            if matches:
                return matches[0]

    ignored = ("setup", "install", "config", "sound", "setsound", "uninst", "end", "open", "drv")
    usable = [path for path in candidates if not path.stem.casefold().startswith(ignored)]
    return (usable or candidates)[0]


def prepare_dos_game(game: dict, rom: Path) -> tuple[Path, Path | None]:
    digest = hashlib.sha256(str(game["id"]).encode("utf-8")).hexdigest()[:20]
    destination = CACHE_DIR / "dos" / digest
    destination.mkdir(parents=True, exist_ok=True)
    if not any(destination.iterdir()):
        safe_extract(rom, destination)
    startup = find_dos_startup(destination)
    if startup is None:
        return destination, None

    # DOSBox 0.74 cannot display a UTF-8 host path. Mount an ASCII-only symlink
    # directly to the executable directory so both its console and relative data
    # lookups stay valid.
    roots = CACHE_DIR / "dos-roots"
    roots.mkdir(parents=True, exist_ok=True)
    dos_root = roots / digest
    if dos_root.is_symlink() and dos_root.resolve() != startup.parent.resolve():
        dos_root.unlink()
    if not dos_root.exists():
        dos_root.symlink_to(startup.parent, target_is_directory=True)
    return dos_root, startup


def dosbox_command(dosbox: str, dos_root: Path, startup: Path | None) -> list[str]:
    command = [dosbox, "-fullscreen", "-c", f'mount c "{dos_root}"', "-c", "c:"]
    if startup is not None:
        command.extend(["-c", startup.name, "-c", "exit"])
    return command


class PixelRelay(Gtk.Application):
    def __init__(self) -> None:
        super().__init__(application_id="ai.openai.pixelrelay", flags=Gio.ApplicationFlags.FLAGS_NONE)
        self.window: Gtk.ApplicationWindow | None = None
        self.root: Gtk.Box | None = None
        self.header: Gtk.Box | None = None
        self.header_actions: Gtk.Box | None = None
        self.grid: Gtk.FlowBox | None = None
        self.scroll: Gtk.ScrolledWindow | None = None
        self.status: Gtk.Label | None = None
        self.page_label: Gtk.Label | None = None
        self.previous_button: Gtk.Button | None = None
        self.next_button: Gtk.Button | None = None
        self.filter_buttons: dict[str, Gtk.Button] = {}
        self.active_filter = "all"
        self.compact_layout: bool | None = None
        self.layout_columns = 0
        self.current_page = 0
        self.render_generation = 0
        self.thumbnail_pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="poster-cache")
        self.thumbnail_futures: list[Future[Path | None]] = []

    def do_startup(self) -> None:
        Gtk.Application.do_startup(self)
        provider = Gtk.CssProvider()
        provider.load_from_path(str(APP_DIR / "styles.css"))
        Gtk.StyleContext.add_provider_for_screen(
            Gdk.Screen.get_default(), provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
        )

    def do_activate(self) -> None:
        if self.window:
            self.window.present()
            return

        self.window = Gtk.ApplicationWindow(application=self)
        self.window.set_title("Pixel Relay 本地游戏厅")
        self.window.set_default_size(1100, 720)
        if not WINDOWED:
            self.window.fullscreen()
        self.window.connect("key-press-event", self.on_key_press)
        self.window.connect("size-allocate", self.on_size_allocate)

        root = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=16)
        root.set_border_width(24)
        self.root = root
        self.window.add(root)

        header = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=14)
        self.header = header
        heading = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        title = Gtk.Label(label="PIXEL RELAY", xalign=0)
        title.get_style_context().add_class("title")
        subtitle = Gtk.Label(label="树莓派原生游戏厅 · GTK + RetroArch · 无浏览器内核", xalign=0)
        subtitle.set_line_wrap(True)
        subtitle.get_style_context().add_class("subtitle")
        heading.pack_start(title, False, False, 0)
        heading.pack_start(subtitle, False, False, 0)
        header.pack_start(heading, True, True, 0)

        header_actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        header_actions.set_hexpand(False)
        header_actions.set_halign(Gtk.Align.END)
        self.header_actions = header_actions
        import_button = Gtk.Button()
        import_icon = Gtk.Image.new_from_icon_name("document-open-symbolic", Gtk.IconSize.BUTTON)
        import_icon.set_pixel_size(22)
        import_button.add(import_icon)
        import_button.set_tooltip_text("导入我的 ROM")
        import_button.get_accessible().set_name("导入我的 ROM")
        import_button.get_style_context().add_class("secondary")
        import_button.get_style_context().add_class("icon-action")
        import_button.connect("clicked", self.on_import)
        header_actions.pack_start(import_button, False, False, 0)

        quit_button = Gtk.Button()
        quit_icon = Gtk.Image.new_from_icon_name("application-exit-symbolic", Gtk.IconSize.BUTTON)
        quit_icon.set_pixel_size(22)
        quit_button.add(quit_icon)
        quit_button.set_tooltip_text("退出 Pixel Relay")
        quit_button.get_accessible().set_name("退出 Pixel Relay")
        quit_button.get_style_context().add_class("secondary")
        quit_button.get_style_context().add_class("icon-action")
        quit_button.get_style_context().add_class("danger")
        quit_button.connect("clicked", lambda _button: self.quit())
        header_actions.pack_start(quit_button, False, False, 0)
        header.pack_start(header_actions, False, False, 0)
        root.pack_start(header, False, False, 0)

        filters = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        for system in ["all", *SYSTEMS.keys()]:
            button = Gtk.Button(label=FILTER_LABELS[system])
            button.set_tooltip_text("全部游戏" if system == "all" else SYSTEMS[system]["name"])
            button.get_style_context().add_class("filter")
            button.connect("clicked", self.on_filter, system)
            self.filter_buttons[system] = button
            filters.pack_start(button, False, False, 0)
        filter_scroll = Gtk.ScrolledWindow()
        filter_scroll.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.NEVER)
        filter_scroll.set_kinetic_scrolling(True)
        filter_scroll.set_overlay_scrolling(True)
        filter_scroll.set_propagate_natural_width(False)
        filter_scroll.add(filters)
        filter_scroll.set_min_content_height(64)
        root.pack_start(filter_scroll, False, False, 0)

        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_kinetic_scrolling(True)
        scroll.set_overlay_scrolling(True)
        scroll.set_propagate_natural_height(False)
        self.scroll = scroll
        self.grid = Gtk.FlowBox()
        self.grid.set_selection_mode(Gtk.SelectionMode.NONE)
        self.grid.set_homogeneous(True)
        self.grid.set_halign(Gtk.Align.FILL)
        self.grid.set_valign(Gtk.Align.START)
        self.grid.set_hexpand(True)
        self.grid.set_min_children_per_line(4)
        self.grid.set_max_children_per_line(4)
        self.grid.set_row_spacing(14)
        self.grid.set_column_spacing(14)
        scroll.add(self.grid)
        root.pack_start(scroll, True, True, 0)

        footer = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        self.status = Gtk.Label(label="方向键选择，Enter 确认；PgUp/PgDn 翻页。", xalign=0)
        self.status.set_line_wrap(True)
        self.status.set_hexpand(True)
        self.status.get_style_context().add_class("status")
        footer.pack_start(self.status, True, True, 0)

        pager = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        pager.get_style_context().add_class("pager")
        self.previous_button = self.make_page_button("go-previous-symbolic", "上一页")
        self.previous_button.connect("clicked", self.on_page, -1)
        pager.pack_start(self.previous_button, False, False, 0)
        self.page_label = Gtk.Label(label="1 / 1")
        self.page_label.set_width_chars(9)
        self.page_label.get_style_context().add_class("page-label")
        pager.pack_start(self.page_label, False, False, 0)
        self.next_button = self.make_page_button("go-next-symbolic", "下一页")
        self.next_button.connect("clicked", self.on_page, 1)
        pager.pack_start(self.next_button, False, False, 0)
        footer.pack_end(pager, False, False, 0)
        root.pack_start(footer, False, False, 0)

        self.refresh()
        self.window.show_all()

    def do_shutdown(self) -> None:
        self.render_generation += 1
        for future in self.thumbnail_futures:
            future.cancel()
        self.thumbnail_pool.shutdown(wait=False, cancel_futures=True)
        Gtk.Application.do_shutdown(self)

    @staticmethod
    def make_page_button(icon_name: str, accessible_name: str) -> Gtk.Button:
        button = Gtk.Button()
        icon = Gtk.Image.new_from_icon_name(icon_name, Gtk.IconSize.BUTTON)
        icon.set_pixel_size(22)
        button.add(icon)
        button.set_tooltip_text(accessible_name)
        button.get_accessible().set_name(accessible_name)
        button.get_style_context().add_class("secondary")
        button.get_style_context().add_class("page-action")
        return button

    def on_size_allocate(self, _window: Gtk.Window, allocation: Gdk.Rectangle) -> None:
        compact = allocation.width < 900
        if compact != self.compact_layout:
            self.compact_layout = compact
            if self.root:
                self.root.set_border_width(12 if compact else 24)
                self.root.set_spacing(10 if compact else 16)
            if self.header:
                self.header.set_orientation(Gtk.Orientation.HORIZONTAL)
                self.header.set_spacing(8 if compact else 14)
            if self.header_actions:
                self.header_actions.set_halign(Gtk.Align.END)
            if self.window:
                style = self.window.get_style_context()
                if compact:
                    style.add_class("compact")
                else:
                    style.remove_class("compact")

        if allocation.width < 520:
            columns = 2
        elif allocation.width < 720:
            columns = 3
        elif allocation.width < 1050:
            columns = 4
        else:
            columns = 5
        if self.grid and columns != self.layout_columns:
            self.layout_columns = columns
            self.grid.set_min_children_per_line(columns)
            self.grid.set_max_children_per_line(columns)

    def on_key_press(self, _window: Gtk.Window, event: Gdk.EventKey) -> bool:
        if event.keyval == Gdk.KEY_F11:
            if self.window:
                self.window.unfullscreen()
            return True
        if event.keyval == Gdk.KEY_F5:
            self.refresh(reload=True)
            return True
        if event.keyval == Gdk.KEY_Page_Up:
            self.change_page(-1)
            return True
        if event.keyval == Gdk.KEY_Page_Down:
            self.change_page(1)
            return True
        return False

    def on_filter(self, _button: Gtk.Button, system: str) -> None:
        self.active_filter = system
        self.current_page = 0
        self.refresh()

    def refresh(self, reload: bool = False) -> None:
        assert self.grid is not None
        for future in self.thumbnail_futures:
            future.cancel()
        self.thumbnail_futures.clear()
        for system, button in self.filter_buttons.items():
            style = button.get_style_context()
            if system == self.active_filter:
                style.add_class("active")
            else:
                style.remove_class("active")
        for child in self.grid.get_children():
            self.grid.remove(child)
        if reload:
            if self.status:
                self.status.set_text("正在扫描 ROM 并更新本地索引…")
                while Gtk.events_pending():
                    Gtk.main_iteration_do(False)
            rebuild_game_index()
            self.current_page = 0
        else:
            ensure_game_index()

        visible, total = query_game_page(self.active_filter, self.current_page)
        page_count = max(1, math.ceil(total / POSTER_PAGE_SIZE))
        if self.current_page >= page_count:
            self.current_page = page_count - 1
            visible, total = query_game_page(self.active_filter, self.current_page)
        self.render_generation += 1
        generation = self.render_generation
        for game in visible:
            self.grid.add(self.make_card(game, generation))
        self.grid.show_all()
        if self.page_label:
            self.page_label.set_text(f"{self.current_page + 1} / {page_count}")
        if self.previous_button:
            self.previous_button.set_sensitive(self.current_page > 0)
        if self.next_button:
            self.next_button.set_sensitive(self.current_page + 1 < page_count)
        if self.scroll:
            GLib.idle_add(self.scroll.get_vadjustment().set_value, 0)
        if self.status:
            network_count = indexed_network_count()
            status_style = self.status.get_style_context()
            mount_state = network_mount_state()
            first = self.current_page * POSTER_PAGE_SIZE + 1 if total else 0
            last = min((self.current_page + 1) * POSTER_PAGE_SIZE, total)
            if mount_state == "mounted":
                status_style.remove_class("network-warning")
                self.status.set_text(
                    f"局域网 {network_count} 款 · 本页 {first}–{last}/{total} · F5 更新索引"
                )
            elif mount_state == "configured":
                status_style.add_class("network-warning")
                self.status.set_text(
                    f"NAS 暂未连接 · 正在使用本地索引 {first}–{last}/{total} · F5 重试"
                )
            else:
                status_style.add_class("network-warning")
                self.status.set_text(
                    f"局域网 ROM 尚未配置 · 本页 {first}–{last}/{total} · F5 更新索引"
                )

    def on_page(self, _button: Gtk.Button, delta: int) -> None:
        self.change_page(delta)

    def change_page(self, delta: int) -> None:
        target = self.current_page + delta
        if target < 0:
            return
        self.current_page = target
        self.refresh()

    def make_card(self, game: dict, generation: int) -> Gtk.Widget:
        card = Gtk.Button()
        card.set_size_request(-1, 286)
        card.set_hexpand(True)
        card.set_tooltip_text(game.get("description", "点击启动游戏"))
        card.get_accessible().set_name(f"启动 {game['title']}")
        card.get_style_context().add_class("poster-card")
        card.connect("clicked", self.on_play, game)

        content = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=0)
        art = Gtk.Overlay()
        art.set_size_request(-1, 202)
        art.get_style_context().add_class("poster-art")
        art.get_style_context().add_class(f"system-{game['system']}")
        cached = thumbnail_path(game)
        image_loaded = False
        if cached.is_file():
            try:
                pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(cached))
                image = Gtk.Image.new_from_pixbuf(pixbuf)
                image.set_halign(Gtk.Align.CENTER)
                image.set_valign(Gtk.Align.CENTER)
                art.add(image)
                image_loaded = True
            except GLib.Error:
                cached.unlink(missing_ok=True)
        if not image_loaded:
            mark = Gtk.Label(label=FILTER_LABELS[game["system"]])
            mark.set_halign(Gtk.Align.CENTER)
            mark.set_valign(Gtk.Align.CENTER)
            mark.get_style_context().add_class("poster-mark")
            art.add(mark)
            self.queue_thumbnail(game, card, art, mark, generation)
        content.pack_start(art, True, True, 0)

        info = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        info.get_style_context().add_class("poster-info")
        title = Gtk.Label(label=game["title"], xalign=0)
        title.set_line_wrap(True)
        title.set_lines(2)
        title.get_style_context().add_class("poster-title")
        system = Gtk.Label(label=SYSTEMS[game["system"]]["name"], xalign=0)
        system.get_style_context().add_class("poster-system")
        info.pack_start(title, True, True, 0)
        info.pack_start(system, False, False, 0)
        content.pack_start(info, False, False, 0)
        card.add(content)
        return card

    def queue_thumbnail(
        self,
        game: dict,
        card: Gtk.Button,
        art: Gtk.Overlay,
        placeholder: Gtk.Label,
        generation: int,
    ) -> None:
        future = self.thumbnail_pool.submit(build_thumbnail, dict(game))
        self.thumbnail_futures.append(future)

        def completed(result: Future[Path | None]) -> None:
            try:
                path = result.result()
            except Exception:
                path = None
            if path is not None:
                GLib.idle_add(
                    self.apply_thumbnail,
                    path,
                    card,
                    art,
                    placeholder,
                    generation,
                )

        future.add_done_callback(completed)

    def apply_thumbnail(
        self,
        path: Path,
        card: Gtk.Button,
        art: Gtk.Overlay,
        placeholder: Gtk.Label,
        generation: int,
    ) -> bool:
        if generation != self.render_generation or card.get_parent() is None:
            return False
        try:
            pixbuf = GdkPixbuf.Pixbuf.new_from_file(str(path))
        except GLib.Error:
            return False
        if placeholder.get_parent() is art:
            art.remove(placeholder)
        image = Gtk.Image.new_from_pixbuf(pixbuf)
        image.set_halign(Gtk.Align.CENTER)
        image.set_valign(Gtk.Align.CENTER)
        art.add(image)
        image.show()
        return False

    def show_error(self, title: str, detail: str) -> None:
        dialog = Gtk.MessageDialog(
            transient_for=self.window,
            modal=True,
            message_type=Gtk.MessageType.ERROR,
            buttons=Gtk.ButtonsType.CLOSE,
            text=title,
        )
        dialog.format_secondary_text(detail)
        dialog.run()
        dialog.destroy()

    def on_license(self, _button: Gtk.Button, game: dict) -> None:
        path = resolve_asset(game["license"])
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            self.show_error("无法读取授权文件", str(exc))
            return
        dialog = Gtk.Dialog(title=f"{game['title']} · 授权", transient_for=self.window, modal=True)
        dialog.add_button("关闭", Gtk.ResponseType.CLOSE)
        dialog.set_default_size(720, 500)
        view = Gtk.TextView(editable=False, cursor_visible=False, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        view.get_buffer().set_text(text)
        scroll = Gtk.ScrolledWindow()
        scroll.add(view)
        dialog.get_content_area().pack_start(scroll, True, True, 10)
        dialog.show_all()
        dialog.run()
        dialog.destroy()

    def on_play(self, _button: Gtk.Button, game: dict) -> None:
        rom = resolve_asset(game["rom"])
        if not rom.exists():
            self.show_error("找不到游戏文件", str(rom))
            return
        system = game["system"]
        core = find_core(system)
        retroarch = shutil.which("retroarch")
        if retroarch and core:
            config = APP_DIR / "retroarch-pi.cfg"
            command = [retroarch, "--fullscreen", "--appendconfig", str(config), "-L", str(core), str(rom)]
        elif system == "dos":
            dosbox = shutil.which("dosbox-staging") or shutil.which("dosbox")
            if not dosbox:
                self.show_error("缺少 DOS 模拟器", "请重新运行 install.sh，或安装 dosbox-staging。")
                return
            try:
                dos_root, startup = prepare_dos_game(game, rom)
            except (OSError, zipfile.BadZipFile, ValueError) as exc:
                self.show_error("无法解压 DOS 游戏", str(exc))
                return
            command = dosbox_command(dosbox, dos_root, startup)
        else:
            tried = "、".join(SYSTEMS[system]["cores"])
            self.show_error("缺少模拟器核心", f"系统需要：{tried}\n请重新运行 pi-app/install.sh。")
            return

        if self.status:
            self.status.set_text(f"正在启动 {game['title']}…")
        try:
            subprocess.Popen(command, cwd=str(rom.parent), start_new_session=True)
        except OSError as exc:
            self.show_error("启动失败", str(exc))

    def on_import(self, _button: Gtk.Button) -> None:
        chooser = Gtk.FileChooserDialog(
            title="导入你拥有使用权的 ROM",
            transient_for=self.window,
            action=Gtk.FileChooserAction.OPEN,
        )
        chooser.add_buttons("取消", Gtk.ResponseType.CANCEL, "导入", Gtk.ResponseType.OK)
        file_filter = Gtk.FileFilter()
        file_filter.set_name("支持的 ROM")
        for pattern in ("*.nes", "*.gb", "*.gbc", "*.gba", "*.md", "*.gen", "*.bin", "*.sfc", "*.smc", "*.a26", "*.n64", "*.v64", "*.z64", "*.zip"):
            file_filter.add_pattern(pattern)
        chooser.add_filter(file_filter)
        response = chooser.run()
        filename = chooser.get_filename()
        chooser.destroy()
        if response != Gtk.ResponseType.OK or not filename:
            return

        source = Path(filename)
        matching = [key for key, cfg in SYSTEMS.items() if source.suffix.lower() in cfg["extensions"]]
        if not matching:
            self.show_error("不支持这个文件", source.suffix or "没有扩展名")
            return
        system = matching[0]
        if len(matching) > 1:
            system = self.choose_system(matching)
            if not system:
                return

        USER_ROM_DIR.mkdir(parents=True, exist_ok=True)
        destination = USER_ROM_DIR / source.name
        counter = 1
        while destination.exists():
            destination = USER_ROM_DIR / f"{source.stem}-{counter}{source.suffix}"
            counter += 1
        try:
            shutil.copy2(source, destination)
            current = {"version": 1, "games": []}
            if USER_LIBRARY.exists():
                current = json.loads(USER_LIBRARY.read_text(encoding="utf-8"))
            current.setdefault("games", []).append(
                {
                    "id": f"user-{destination.stem}-{int(destination.stat().st_mtime)}",
                    "title": source.stem,
                    "system": system,
                    "rom": str(destination),
                    "description": "我的本地 ROM（不会上传或分享）",
                }
            )
            USER_LIBRARY.write_text(json.dumps(current, ensure_ascii=False, indent=2), encoding="utf-8")
        except (OSError, json.JSONDecodeError) as exc:
            self.show_error("导入失败", str(exc))
            return
        self.current_page = 0
        self.refresh(reload=True)

    def choose_system(self, systems: list[str]) -> str | None:
        dialog = Gtk.Dialog(title="选择机型", transient_for=self.window, modal=True)
        dialog.add_buttons("取消", Gtk.ResponseType.CANCEL, "确认", Gtk.ResponseType.OK)
        combo = Gtk.ComboBoxText()
        for system in systems:
            combo.append(system, SYSTEMS[system]["name"])
        combo.set_active(0)
        dialog.get_content_area().pack_start(combo, False, False, 16)
        dialog.show_all()
        response = dialog.run()
        selected = combo.get_active_id() if response == Gtk.ResponseType.OK else None
        dialog.destroy()
        return selected


if __name__ == "__main__":
    if "--windowed" in sys.argv:
        sys.argv.remove("--windowed")
    application = PixelRelay()
    raise SystemExit(application.run(sys.argv))

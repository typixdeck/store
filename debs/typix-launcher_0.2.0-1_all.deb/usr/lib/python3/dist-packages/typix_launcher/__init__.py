"""TypixDeck native GTK3 launcher and application supervisor."""

__version__ = "0.2.0"
